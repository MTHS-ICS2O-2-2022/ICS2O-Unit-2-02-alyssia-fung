// Copyright (c) 2023 Alyssiafung All rights reserved
//
// Created by: Alyssia Fung
// Created on: march 2023
// This file contains the JS functions for index.html
function myButtonClicked() {
  alert("Hello, Wordl!")
}

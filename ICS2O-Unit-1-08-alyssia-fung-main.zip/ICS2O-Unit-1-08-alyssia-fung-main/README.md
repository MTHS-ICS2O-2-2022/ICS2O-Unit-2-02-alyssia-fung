# ICS2O Unit #X-YY

[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-f4981d0f882b2a3f0472912d15f9806d57e124e0fc890972558857b51b24a6f9.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=10331521)

[![Mr Coxall's Super Linter](https://github.com/MTHS-ICS2O-2-2022/ICS2O-Unit-1-08-alyssia-fung/workflows/Mr%20Coxall's%20Super%20Linter/badge.svg)](https://github.com/MTHS-ICS2O-2-2022/ICS2O-Unit-1-08-alyssia-fung/actions)

[![Deploy Pages](https://github.com/MTHS-ICS2O-2-2022/ICS2O-Unit-1-08-alyssia-fung/workflows/Deploy%20Pages/badge.svg)](https://github.com/MTHS-ICS2O-2-2022/ICS2O-Unit-1-08-alyssia-fung/actions)

This site can be found at: [https://MTHS-ICS2O-2-2022.github.io/ICS2O-Unit-1-08-alyssia-fung](https://MTHS-ICS2O-2-2022.github.io/ICS2O-Unit-1-08-alyssia-fung)

---

**NOTES ON INITIAL LOAD:**
- remember to goto on the menu bar:
  - File
  - Go to Repository
  - ⚙ Settings
  - 🗔 Pages
    - then from the "Deploy from a branch ▼" button, select "GitHub Actions"
